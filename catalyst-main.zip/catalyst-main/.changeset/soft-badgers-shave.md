---
"@bigcommerce/catalyst-core": patch
---

Add update address mutation
