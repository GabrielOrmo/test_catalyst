---
"@bigcommerce/components": minor
"@bigcommerce/docs": minor
---

Add dialog component
