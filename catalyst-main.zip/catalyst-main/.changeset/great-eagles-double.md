---
"@bigcommerce/catalyst-core": patch
---

standardize mutations by returning drilled response
