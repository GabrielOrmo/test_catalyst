---
"@bigcommerce/catalyst-core": minor
---

Add customer addresses tab content
