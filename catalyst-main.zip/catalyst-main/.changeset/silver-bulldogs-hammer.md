---
"@bigcommerce/catalyst-core": patch
---

check for auth on /account pages
