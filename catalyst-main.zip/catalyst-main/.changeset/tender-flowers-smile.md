---
"@bigcommerce/catalyst-core": patch
---

Add customer addresses query
