---
"@bigcommerce/catalyst-core": patch
---

Add missing `Cart.spinnerText` translation.
