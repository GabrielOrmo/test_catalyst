---
"@bigcommerce/catalyst-core": patch
---

Add delete customer address mutation
