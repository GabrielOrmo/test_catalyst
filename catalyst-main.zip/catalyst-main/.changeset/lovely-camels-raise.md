---
"@bigcommerce/create-catalyst": minor
---

Adds an option to include the functional test suite as part of the create command. Defaults to false.
