---
"@bigcommerce/components": patch
"@bigcommerce/catalyst-core": patch
---

add accessible attr for select component
