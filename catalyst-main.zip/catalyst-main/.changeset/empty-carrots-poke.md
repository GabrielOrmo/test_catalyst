---
"@bigcommerce/catalyst-core": patch
---

use LRU cache for DevKvAdapter
