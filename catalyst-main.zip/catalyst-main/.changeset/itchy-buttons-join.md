---
"@bigcommerce/components": patch
"@bigcommerce/catalyst-core": patch
"@bigcommerce/docs": patch
---

Update `tailwindFunctions` to use the correct className utility function `cn`.
