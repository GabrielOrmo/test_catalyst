---
"@bigcommerce/catalyst-core": patch
---

best-effort in memory cache for vercel kv adapter
