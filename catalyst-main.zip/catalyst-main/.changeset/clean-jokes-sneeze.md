---
"@bigcommerce/create-catalyst": minor
---

Adds the `.vscode/settings.json` file pointing to the correct typescript sdk for gql-tada support.
