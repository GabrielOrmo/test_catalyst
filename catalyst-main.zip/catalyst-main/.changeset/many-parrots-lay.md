---
"@bigcommerce/catalyst-core": patch
---

Add customer address mutation
