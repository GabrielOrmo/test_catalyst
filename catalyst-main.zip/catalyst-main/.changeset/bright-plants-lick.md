---
"@bigcommerce/catalyst-core": patch
---

add update customer mutation
