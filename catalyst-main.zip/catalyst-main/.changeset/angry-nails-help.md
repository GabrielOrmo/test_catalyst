---
"@bigcommerce/catalyst-core": patch
---

Apply the edge runtime to missing routes.
