---
"@bigcommerce/catalyst-core": patch
---

add get customer query
