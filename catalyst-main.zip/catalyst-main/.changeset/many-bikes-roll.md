---
"@bigcommerce/catalyst-core": patch
---

split contact us and normal websites into individual pages
