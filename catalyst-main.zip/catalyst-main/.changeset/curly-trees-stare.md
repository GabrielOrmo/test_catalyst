---
"@bigcommerce/catalyst-core": patch
---

use next-intl formatter to properly localize dates & prices
