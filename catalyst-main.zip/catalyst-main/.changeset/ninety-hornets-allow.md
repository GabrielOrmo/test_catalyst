---
"@bigcommerce/catalyst-core": patch
---

add loading state on item quantity update and remove when quantity equals 0
