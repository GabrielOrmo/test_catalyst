module.exports = {
  transformIgnorePatterns: [],
  transform: {
    '^.+\\.(t|j)s?$': '@swc/jest',
  },
};
