'use client';

export * from './label';
