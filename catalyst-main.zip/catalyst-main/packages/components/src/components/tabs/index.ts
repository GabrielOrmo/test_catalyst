'use client';

export * from './tabs';
