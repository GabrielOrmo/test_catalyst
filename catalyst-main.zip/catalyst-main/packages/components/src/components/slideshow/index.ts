'use client';

export * from './slideshow';
