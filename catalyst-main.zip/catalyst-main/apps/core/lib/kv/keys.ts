export const STORE_STATUS_KEY = 'storeStatus';
export const routeCacheKvKey = (pathname: string) => `v3_${pathname}`;
